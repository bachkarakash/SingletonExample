package com.singleton.example;

import java.util.Scanner;

public class User
{
	public static void main(String[] args)
	{
		System.out.println("This is Singleton Example: \nSpecify Logger among (File,Date,Database)");
		Scanner sc = new Scanner(System.in);
		String typeOfLogger = sc.next();
		SingletonLogger onlyObject = SingletonLogger.getOnlyObject(typeOfLogger); //Passing type of Logger as an argument
		onlyObject.testLogger();
		sc.close();
	}

}
