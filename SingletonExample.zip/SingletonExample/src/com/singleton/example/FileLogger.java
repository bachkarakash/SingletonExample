package com.singleton.example;

public class FileLogger implements Logger
{
	@Override
	public void getLog() {
		// TODO Auto-generated method stub
		System.out.println("This is File Logger");
		
	}

}
