package com.singleton.example;

public class DatabaseLogger implements Logger
{
	@Override
	public void getLog() {
		// TODO Auto-generated method stub
		System.out.println("This is Database Logger");
	}

}
