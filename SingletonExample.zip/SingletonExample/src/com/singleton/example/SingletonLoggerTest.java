package com.singleton.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SingletonLoggerTest 
{
	SingletonLogger onlyObject=null;
	@BeforeEach
	public void setUp() throws Exception
	{
		onlyObject = SingletonLogger.getOnlyObject("Date");
		System.out.println("Before");
	}

	@Test
	void testDatabaseLogger() 
	{
		assertTrue(onlyObject.setLoggerObject("Database"));
	}
	
}
