package com.singleton.example;

public interface Logger 
{
	public void getLog();

}
