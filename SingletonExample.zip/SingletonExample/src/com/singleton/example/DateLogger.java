package com.singleton.example;

import java.util.Date;

public class DateLogger implements Logger
{
	@Override
	public void getLog() {
		// TODO Auto-generated method stub
		Date date = new Date();
		System.out.println(date);
	}

}
