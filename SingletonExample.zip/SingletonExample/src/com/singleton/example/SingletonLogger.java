package com.singleton.example;

public class SingletonLogger
{
	private static final Exception Exception = null;
	private static SingletonLogger OnlyObject;
	static Logger loggerObject;
	private SingletonLogger() {}
	public static SingletonLogger getOnlyObject(String typeOfLogger) 
	{
		if(OnlyObject==null)
			OnlyObject = new SingletonLogger();
		OnlyObject.setLoggerObject(typeOfLogger);
		return OnlyObject;
	}
	//Initializing Logger Object as either Date,File or Database Logger
	public void setLoggerObject(String typeOfLogger)
	{
		if(typeOfLogger.equals("Date"))
			loggerObject = new DateLogger();
		else if(typeOfLogger.equals("Database"))
			loggerObject = new DatabaseLogger();
		else if(typeOfLogger.equals("File"))
			loggerObject = new FileLogger();
		else
			try {
				throw Exception;
			} catch (java.lang.Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Cannot create Logger Object");
				System.exit(0);
			}
	}
	public void testLogger()
	{
		loggerObject.getLog();
	}
}